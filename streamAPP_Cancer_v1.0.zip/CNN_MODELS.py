#import random
#import os
#import pickle
#from tqdm import tqdm
#from time import time
#import pandas as pd
#from glob import glob
import torch
import torch.nn as nn
#from PIL import Image
#from torch.utils.data import Dataset, DataLoader, random_split
#import torchvision
#import torchvision.transforms as transforms

#####################################################

class SeparableConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0):
        super(SeparableConv2d, self).__init__()
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size, stride=stride, padding=padding, groups=in_channels)
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x


# CONVOLUTIONAL NN | S | pix=192 | 4 layers
#####################################################

class CNN_S(nn.Module):
    def __init__(self, num_classes):
        super(CNN_S, self).__init__()
        self.layer1 = nn.Sequential(
            SeparableConv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            SeparableConv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            SeparableConv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            SeparableConv2d(128, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv1d = nn.Conv2d(256, 3, kernel_size=1)
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(3*12*12, num_classes)
     )

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.conv1d(x)
        x = self.classifier(x)
        return x

# CONVOLUTIONAL NEURAL NET | M | pix=384 | 5 layers
#####################################################

class CNN_M_5lay(nn.Module):
    def __init__(self, num_classes):
        super(CNN_M_5lay, self).__init__()
        self.layer1 = nn.Sequential(
            SeparableConv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            SeparableConv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            SeparableConv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            SeparableConv2d(128, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer5 = nn.Sequential(
            SeparableConv2d(256, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv1d = nn.Sequential(
            nn.Conv2d(128, 64, kernel_size=1),
            nn.Conv2d(64, 3, kernel_size=1)
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(3*12*12, num_classes)
     )

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.layer5(x)        
        x = self.conv1d(x)
        x = self.classifier(x)
        return x

# CONVOLUTIONAL NEURAL NET | M | pix=384 | 6 layers
#####################################################
class CNN_M_6lay(nn.Module):
    def __init__(self, num_classes):
        super(CNN_M_6lay, self).__init__()
        self.layer1 = nn.Sequential(
            SeparableConv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            SeparableConv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            SeparableConv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            SeparableConv2d(128, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer5 = nn.Sequential(
            SeparableConv2d(256, 512, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer6 = nn.Sequential(
            SeparableConv2d(512, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv1d = nn.Sequential(
            nn.Conv2d(256, 64, kernel_size=1),
            nn.Conv2d(64, 3, kernel_size=1),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(3*6**2, num_classes)
     )

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.layer5(x)
        x = self.layer6(x)
        x = self.conv1d(x)
        x = self.classifier(x)
        return x


# CONVOLUTIONAL NEURAL NET | L | pix=768 | 3 LAYERS
#####################################################
class CNN_L_3lay(nn.Module):
    def __init__(self, num_classes):
        super(CNN_L_3lay, self).__init__()
        self.layer1 = nn.Sequential(
            SeparableConv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            SeparableConv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            SeparableConv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv1d = nn.Conv2d(128, 3, kernel_size=1)
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(3*96*96, num_classes)
     )

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.conv1d(x)
        x = self.classifier(x)
        return x

# CONVOLUTIONAL NEURAL NET | L | pix=768 | 4 LAYERS
#####################################################
class CNN_L_4lay(nn.Module):
    def __init__(self, num_classes):
        super(CNN_L_4lay, self).__init__()
        self.layer1 = nn.Sequential(
            SeparableConv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            SeparableConv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            SeparableConv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            SeparableConv2d(128, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv1d = nn.Conv2d(256, 3, kernel_size=1)
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(3*48*48, num_classes)
     )

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.conv1d(x)
        x = self.classifier(x)
        return x



# CONVOLUTIONAL NEURAL NET | L | pix=768 | 6 LAYERS
#####################################################

class CNN_L_6lay(nn.Module):
    def __init__(self, num_classes):
        super(CNN_L_6lay, self).__init__()
        self.layer1 = nn.Sequential(
            SeparableConv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            SeparableConv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            SeparableConv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            SeparableConv2d(128, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer5 = nn.Sequential(
            SeparableConv2d(256, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer6 = nn.Sequential(
            SeparableConv2d(128, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv1d = nn.Sequential(
            nn.Conv2d(64, 3, kernel_size=1),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(3*12**2, num_classes)
     )

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.layer5(x)
        x = self.layer6(x)                
        x = self.conv1d(x)
        x = self.classifier(x)
        return x

# CONVOLUTIONAL NEURAL NET | L | pix=768 | 8 LAYERS
#####################################################
#class CNN_L(nn.Module):
class CNN_L_8lay(nn.Module):
    def __init__(self, num_classes):
#        super(CNN_L, self).__init__()
        super(CNN_L_8lay, self).__init__()
        self.layer1 = nn.Sequential(
            SeparableConv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            SeparableConv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            SeparableConv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            SeparableConv2d(128, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer5 = nn.Sequential(
            SeparableConv2d(256, 512, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer6 = nn.Sequential(
            SeparableConv2d(512, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer7 = nn.Sequential(
            SeparableConv2d(256, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer8 = nn.Sequential(
            SeparableConv2d(128, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv1d = nn.Sequential(
            nn.Conv2d(64, 3, kernel_size=1),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(3*3**2, num_classes)
     )

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.layer5(x)
        x = self.layer6(x)
        x = self.layer7(x)
        x = self.layer8(x)                
        x = self.conv1d(x)
        x = self.classifier(x)
        return x

