import streamlit as st
import torch
import os
from PIL import Image
from dotenv import load_dotenv
import tempfile
from datetime import datetime
import shutil
import numpy as np

load_dotenv(override=True)

OPENSLIDE_PATH = os.getenv('OPENSLIDE_PATH')
MODEL_PATH = os.getenv('MODEL_PATH')
PM  = float(os.getenv('PM'))
ALPHA = float(os.getenv('ALPHA'))
K = int(os.getenv('K'))
PIX = int(os.getenv('PIX'))

if hasattr(os, 'add_dll_directory'):
    with os.add_dll_directory(OPENSLIDE_PATH):
        import openslide
else:
    import openslide

from CNN_MODELS import CNN_M_5lay
from postp import *



def crop4predict_server(slide, x_min, pix, PM):
    processed_tiles=0
    progress_text = "Operation in progress. Please wait."
    my_bar = st.progress(0, text=progress_text)
    total_y=len(range(0, slide.dimensions[1], pix)[:-1])
    total_x=len(range(x_min, slide.dimensions[0], pix)[:-1])
    total_iterations=(total_x)*(total_y)
    for y in range(0, slide.dimensions[1], pix)[:-1]:
        for x in range(x_min, slide.dimensions[0], pix)[:-1]:
            p = slide.read_region((x, y), 0, (pix, pix)).convert('RGB')
            mask = gauss_blur(np.array(p), 11, 230) // 255
            carne = np.sum(mask[mask == 1]) / pix**2
            if (carne > 0.2) & (carne < PM):
                if np.std(p) > 20:  # supposed to prevent noise shaped like shadow
                    fn = f'0_{x-x_min}_{y}.png'
                    p.save('temp/' + fn)
            elif (carne >= PM):
                if np.std(p) > 20:  # idem
                    fn = f'1_{x-x_min}_{y}.png'
                    p.save('temp/' + fn)
            processed_tiles += 1
            progress = min(processed_tiles / total_iterations, 1)
        my_bar.progress(progress, text=progress_text)
    my_bar.empty()


def tile_image(svs_file, tile_size=PIX):
    check_dir('SALIDA')
    check_dir('temp')
    with tempfile.NamedTemporaryFile(delete=False, suffix=".svs") as tmp:
        tmp.write(svs_file.read())
        tmp_path = tmp.name
    slide = openslide.OpenSlide(tmp_path)
    thumbnail = slide.get_thumbnail((tile_size, tile_size))
    x_min = desde_donde_leer(slide, PIX)
    crop4predict_server(slide, x_min, PIX, PM)  # Pass the path instead of the slide object
    os.remove(tmp_path)
    slide.close()
    return thumbnail


st.set_page_config(page_title="Cancer Segmentation APP",layout="wide")  # Wider layout

# Add logos of three universities with clickable links
st.markdown(
    """
    <style>
        .logo-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 0px;
            background-color: #E3735E;
            padding: 10px;
            width: 100%;
            margin-top: -60px;
        }
        .logo-container a {
            margin: 0 120px;
        }
        .logo-container img {
            height: 80px;
        }
        .stButton {
            background-color: #FFFFFF;
            color: #880808;
            padding: 10px 220px;
            border-radius: 5px;
            cursor: pointer;
        }
        .stButtonContainer {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }
        footer {
            text-align: center;
            margin-top: 300px;
            color: #880808;
            font-size: 16px;
        }

    </style>
    """,
    unsafe_allow_html=True
)

st.markdown(
    """
    <div class="logo-container">
        <a href="https://www.unicamp.br/" target="_blank">
            <img src="https://www.unicamp.br/wp-content/themes/bx-unicamp-multisite/assets/img/logo-unicamp.svg" alt="Universidade Estadual de Campinas">
        </a>
        <a href="https://www.ufro.cl/" target="_blank">
            <img src="https://www.ufro.cl/images/header/Logo-2022-UFRO.png" alt="Universidad de La Frontera">
        </a>
        <a href="https://www.uandes.cl/" target="_blank">
            <img src="https://www.uandes.cl/wp-content/themes/uandes-main/img/elements/logo_uandes_macro.webp" alt="Universidad de Los Andes">
        </a>
    </div>
    """,
    unsafe_allow_html=True
)

st.markdown("<h1 style='text-align: center; color: #880808; margin-top: 0px;'>Prostate Cancer Biopsy Segmentation</h1>", unsafe_allow_html=True)

uploaded_file = st.file_uploader("Upload SVS file", type="svs")
thumbnail = None

if uploaded_file is not None:
    # Check if a new image is uploaded
    if 'uploaded_file' not in st.session_state or st.session_state.uploaded_file != uploaded_file:
        # Clear previous session state for the image
        if 'image_loaded' in st.session_state:
            del st.session_state.image_loaded
        if 'thumbnail' in st.session_state:
            del st.session_state.thumbnail
        if 'button_clicked' in st.session_state:
            del st.session_state.button_clicked

        with st.spinner('Loading image...'):
            thumbnail = tile_image(uploaded_file)
            st.session_state.thumbnail = thumbnail
            st.session_state.image_loaded = True
        st.session_state.uploaded_file = uploaded_file  # Update the uploaded_file in session state

    else:
        thumbnail = st.session_state.thumbnail

    col1, col2 = st.columns([1, 1])

    with col1:
        st.image(thumbnail, caption='Original Image', use_column_width=True)
        with st.container():
            if 'button_clicked' not in st.session_state:
                st.markdown('<div class="stButtonContainer">', unsafe_allow_html=True)
                process_button = st.button("Run Segmentation")
                st.markdown('</div>', unsafe_allow_html=True)

            if process_button:
                st.session_state.button_clicked = True
                with col2:
                    with st.spinner('Segmenting image...'):
                        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
                        # Load Model
                        model = CNN_M_5lay(2)
                        if torch.cuda.is_available():
                            model.load_state_dict(torch.load(MODEL_PATH))
                        else:
                            model.load_state_dict(torch.load(MODEL_PATH, map_location=torch.device('cpu')))
                        model.eval()
                        fs, full_size, o = get_size_orig(PIX)
                        # Process each tile
                        full_image = Image.new('RGB', full_size, (240,240,240))
                        total_tiles = len(fs)
                        processed_tiles=0
                        progress_text = "Prediction in progress. Please wait."
                        my_bar = st.progress(0, text=progress_text)
                        for f in fs:
                            patch = Image.open('temp/'+f)
                            ix, x, y = get_id_xy(f, o)
                            if ix == 1:
                                pred = predict(patch, model)
                                patch = tight_color(patch, pred, ALPHA, K)
                            full_image.paste(patch, (x,y))
                            processed_tiles += 1
                            progress = min(processed_tiles / total_tiles, 1)
                            my_bar.progress(progress, text=progress_text)
                        my_bar.empty()
                        resized_full_image = full_image.resize((PIX, PIX))
                        st.image(resized_full_image, caption='Segmented Image', use_column_width=True)
                        # Clean up temp folder
                        shutil.rmtree('temp')
                        shutil.rmtree('SALIDA')

current_year = datetime.now().year
st.markdown(f"<footer>&copy; {current_year}. All rights reserved.</footer>", unsafe_allow_html=True)
