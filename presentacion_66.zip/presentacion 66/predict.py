# in order to work, must have: 
#   (folder) models: must include model to use
#   (folder) ENTRADA: must just have 1 file (svs) to analyse
#   (file) CNN_MODELS.py: models classes
#   (file) postp.py: utils functions
#
# output:
#   (folder) SALIDA
#               |_____<filename-of-svs-file>_tight.png
#

from CNN_MODELS import CNN_M_5lay
from postp import *
from time import time
import shutil
#import torch
#import os

T = time()

##########################################################################
model_path = 'models/cnn_m_epoch_55.pth'
path = '/home/user/SHARED/System Volume Information/all/all/'

PM = .4     #% de "tejido" necesario en un parche para pasar por predicción del modelo
alpha = 0.3 #intensidad del coloreado . opaco - translucido
k = 255     #intensidad del canal de color

pix = 384 
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
check_dir('SALIDA') ; check_dir('temp')


#svs_name = 'HHHA-2016-01347 A2 DGTE'
#svs_name = 'HHHA-2019-09019 A3 00-40'
#svs_name = 'HHHA-2019-00307 A1  20-60'
#svs_name = 'HHHA-2018-19308 A2 DGTE 0-40'

F = os.listdir('ENTRADA')

if (len(F) != 1) | (F[0][-3:] != 'svs'):
    print('\nPor favor, sólo 1 archivo (svs) en la carpeta ENTRADA. Reintente.\n')
else:
    print('Using:', device)
    # CORTAR EL SVS ESCOGIDO
    ######################################################################### 
    t = time()
    svs_name = F[0][:-4]
    slide = read_svs('ENTRADA/'+F[0])
    print(f'{svs_name} has dimensions:', slide.dimensions, '[pixels]\nStarting cropping...')

    x_min = desde_donde_leer(slide, pix)
    crop4predict(slide, x_min, pix, PM)

    print(f'{svs_name} cropped in {time()-t:.2f} sec.\n')

    # INIT/LOAD MODEL
    ##########################################################################
    model = CNN_M_5lay(2)

    if torch.cuda.is_available():
        torch.load(model_path)
    else:
        state_dict = torch.load(model_path, map_location=torch.device('cpu'))

    model.load_state_dict(state_dict)
    model.eval()

    # READING "TEMP" AND PASTE
    #########################################################################
    fs, full_size, o = get_size_orig(pix)

    t = time()
    print('Starting inference...')
    full_image = Image.new('RGB', full_size, (240,240,240))
    for f in tqdm(fs):
        patch = Image.open('temp/'+f)
        ix, x, y = get_id_xy(f, o)
        if ix == 1:
            pred = predict(patch, model)
            patch = tight_color(patch, pred, alpha, k)
        full_image.paste(patch, (x,y))

    print(f'Annotated by CNN_M in {time()-t:.2f} sec.\n\nStarting save...')
    t = time()
    full_image.save(f'SALIDA/{svs_name}_tight.png')
    print(f'Image saved in {(time()-t):.2f} sec.')


    shutil.rmtree('temp')
    mm,ss = divmod(int(time()-T), 60)
    print(f'\nAll in {mm} min {ss} sec')
