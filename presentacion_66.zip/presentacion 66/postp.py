import os
import cv2
import torch
import numpy as np
from tqdm import tqdm
from PIL import Image
from openslide import OpenSlide
from torchvision.transforms import ToTensor

trans = ToTensor()
#############################################################################
# input: path - carpeta que se desea saber si existe; sino, se crea. 
#
def check_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

#############################################################################
# input: path - svs file a leer
def read_svs(path):
    return OpenSlide(path) 

#############################################################################
# input:    slide - OpenSlide object: del archivo de biopsia que se anotará
# output:   int - pixel desde el cual se leerá el svs para realizar el
#                 cropping para posterior predicción/anotación (x_min)
# ESTA FUNCIÓN SIEMPRE DEJA PARA LEER LO QUE ESTÉ EN LA DERECHA
#
def desde_donde_leer(slide, pix):
    de, thresh = [], 9
    w,h = slide.level_dimensions[-1]
    k = int(slide.level_downsamples[-1])
    xx = np.arange(0,w,pix)[:-1] #sacamos el ultimo pues en el for siempre incluirá una parte negra, aumentando artificialmente el std
    for x in xx: #calcula la desvest por franjas
        pl = slide.read_region((k*x,0), slide.level_count-1, (pix,h)).convert('L')
        de.append( np.std(pl) )

    for i in range(1,len(de)-2):
        if (de[i]>thresh)&(de[i+1]<thresh)&(de[i-1]<thresh) : #evita ruido al medio
            de[i] = .5*(de[i+1]+de[i-1])
        if (i>3)&((de[i-2]<thresh)&(de[i+1]<thresh))&(de[i]>thresh): #evita ruido al medio (en 2 strips)
            de[i] = .5*(de[i-2]+de[i+1])
        elif (i>3)&((de[i-1]<thresh)&(de[i+2]<thresh))&(de[i]>thresh): #idem 
            de[i] = .5*(de[i+2]+de[i-1])
        if (de[i]+1>thresh)&(de[i+1]>thresh+1): #pone como util la que la salva el vecino
            de[i] = .5*(de[i]+de[i+1])

    bool_mask = np.array(de) > thresh
    bool_mask[-1], bool_mask[-2] = True, True
    idx = np.where(bool_mask == False)[0][-1]
    return xx[idx+1]*k #este es o pixel certo no 0-level

#############################################################################
# necesaria para la siguiente funcion:
def gauss_blur(imagen_p, n, threshold): #n=tamaño kernel (IMPAR!) | threshold >= 230
    imagen_gris = cv2.cvtColor(imagen_p, cv2.COLOR_BGR2GRAY)
    imagen_suavizada = cv2.GaussianBlur(imagen_gris, (n,n), 0)
    _, mask_b = cv2.threshold(imagen_suavizada, threshold, 255, cv2.THRESH_BINARY_INV)
    return mask_b

#############################################################################
# input: slide - biopsia a cortar
#        x_min - pixel desde el cual comenzamos a leer
#        pix - tamaño del corte (pixel)
#        PM - porcentaje de "tejido" que debe tener un parche para
#               pasarlo por el modelo y realizar predicción sobre él
#            
def crop4predict(slide, x_min, pix, PM):
    for y in tqdm(range(0, slide.dimensions[1], pix)[:-1]):
        for x in tqdm(range(x_min, slide.dimensions[0], pix)[:-1], leave=False):
            p = slide.read_region((x,y),0,(pix,pix)).convert('RGB')
            mask = gauss_blur(np.array(p), 11, 230) //255 ##############
            carne = np.sum(mask[mask == 1])/pix**2
            if (carne > 0.2) & (carne < PM):
                if np.std(p)>20: #se supone que previene los "ruido con forma de sombra"
                    fn = f'{0}_{x-x_min}_{y}.png'
                    p.save('temp/'+fn)
            elif (carne >= PM):
                if np.std(p)>20: #idem
                    fn = f'{1}_{x-x_min}_{y}.png'
                    p.save('temp/'+fn)

#############################################################################
def get_size_orig(pix):
    fs = os.listdir('temp/')
    xs = [int(f.split('_')[1]) for f in fs]
    ys = [int(f[:-4].split('_')[2]) for f in fs]
    xmin,xmax,ymin,ymax = min(xs), max(xs), min(ys), max(ys)
    orig = (xmin, ymin)
    full_size = (xmax-xmin+pix, ymax-ymin+pix)
    return fs, full_size, orig

#############################################################################
# input: f - filename del parche; creado con la función anterior
#        o - "origen"(x,y) vertice superior izquierdo c/r al slide original
#               en el cual comenzó a cortarse parches útiles 
# output: int: 0 - se pega en la imagen a producir "sin colorear"
#              1 - se "colorea" por el modelo y lueog se pega 
#         int: coordenadas x e y respect. c/r a la imagen a producir
def get_id_xy(f, origin):
    d = f[:-4].split('_')
    return int(d[0]), int(d[1])-origin[0], int(d[2])-origin[1]

#############################################################################
# input: img - imagen PIL del parche a predecir
#        model - modelo que realizará la predicción
# ouptu: int - 0: el parche es Rojo-Cancer
#              1: el parche es Verde-No Cancer
def predict(img, model):
    x = trans(img)
    x = torch.unsqueeze(x, dim=0)
    return torch.argmax(model(x), dim=1).item()

#############################################################################
# input: patch - PIL Image: imagen a la cual se debe diferenciar su fondo
#        alpha - float: intensidad de la máscara (entre 0 y 1)
#        color - int: 0 ó 1 | rojo o verde, según la función anterior
#        k - int: intensidad del canal del color (0-255)
# output: PIL Image para el proceso de reconstrucción
#           la cual está anotada y AJUSTADA a tejido
#   
def tight_color(patch, color, alpha, k=255):
    color = (0,0,k) if color==0 else (0,k,0)
    numpy_image = np.array(patch)
    image = cv2.cvtColor(numpy_image, cv2.COLOR_RGB2BGR)
    lower_bound = np.array([220, 220, 220]) #this really tights it.
    upper_bound = np.array([255, 255, 255])
    mask = cv2.inRange(image, lower_bound, upper_bound)
    foreground_mask = cv2.bitwise_not(mask)
    overlay = np.full_like(image, color, dtype=np.uint8)  
    foreground = cv2.bitwise_and(overlay, overlay, mask=foreground_mask)
    result = cv2.addWeighted(image, 1, foreground, alpha, 0)
    rgb_image = cv2.cvtColor(result, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb_image)


